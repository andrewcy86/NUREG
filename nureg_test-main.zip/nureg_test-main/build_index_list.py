import os
import json
import pathlib

base_folder = os.getcwd()
folder_path = pathlib.PureWindowsPath(base_folder + "\\nureg-doc\\output\\").as_posix() + "/"

def enumerate_html_files(directory):
    # Create an empty list to hold the names of HTML files
    html_files = []

    # Iterate over all files in the specified directory
    for filename in os.listdir(directory):
        # Check if the file is an HTML file
        if filename.endswith('.html') and not filename == "index.html":
            html_files.append(filename)
    
    return html_files

def save_to_json(data, filename):
    # Open the file in write mode and save the JSON data
    with open(folder_path + '../scripts/' + filename, 'w') as json_file:
        json.dump(data, json_file, indent=4)

def main():
    # Enumerate all HTML files in the directory
    html_files = enumerate_html_files(folder_path)

    # Specify the output JSON file name
    output_filename = 'fileList.json'

    # Save the list of HTML files to the JSON file
    save_to_json(html_files, output_filename)

    print(f'List of HTML files has been saved to {output_filename}')

if __name__ == '__main__':
    main()