var relatedSearchField;

var rtaSelection;
var resSelection;
var facilitiesSelection;
var chkSelection;

// var output;

var selectedGroup;

var miniSearchContent = new MiniSearch({
	fields: ['content', 'combined_meta_data', 'section'],
	storeFields: ['content', 'combined_meta_data', 'section']
});
var miniSearchTitle = new MiniSearch({
	fields: ['title', 'combined_meta_data', 'section'],
	storeFields: ['title', 'combined_meta_data', 'section']
});

document.addEventListener('DOMContentLoaded', function () {
	// Function to fetch and process the JSON file
	function loadJSON(file, callback) {
		var xhr = new XMLHttpRequest();
		xhr.overrideMimeType("application/json");
		xhr.open('GET', file, true);
		xhr.onreadystatechange = function () {
			if (xhr.readyState === 4 && xhr.status === 200) {
				callback(JSON.parse(xhr.responseText));
			}
		};
		xhr.send(null);
	}

	// Callback function to handle the JSON data
	function processJSON(data) {
		console.log('JSON Data:', data);
		// Iterate over the JSON array
		data.forEach(function (fileName) {
			indexPage("nureg-doc/output/" + fileName)
		});
	}

	// Load the JSON file and process it
	loadJSON('nureg-doc/scripts/fileList.json', processJSON);

	var toggler = document.getElementsByClassName("caret");
    for (var i = 0; i < toggler.length; i++) {
        toggler[i].addEventListener("click", function() {
            this.parentElement.querySelector(".nested").classList.toggle("active");
            this.classList.toggle("caret-down");
        });
    }

	button = document.getElementById('search_button');

	contentSearchField = document.getElementById('content_search');
	titleSearchField = document.getElementById('title_search');
	relatedSearchField = document.getElementById('related_search');

	rtaSelection = document.getElementById('rta-multi-select');
	resSelection = document.getElementById('res-multi-select');
	facilitiesSelection = document.getElementById('facilities-multi-select');
	chkSelection = document.getElementById('chk-multi-select');

	// output = document.getElementById('SearchOutput');

	selectedGroup = "";

	button.addEventListener('click', function () {
		output.value = ""
		const selectedTags = getSelectedTags()
		const searchInTags = getSearchInTags()
		const contentResults = miniSearchContent.search(contentSearchField.value, {
			filter: (result, term, score, terms) => (selectedTags.length === 0 || getIntersection(result.combined_meta_data, selectedTags).length !== 0) &&
								(searchInTags.length === 0 || getIntersection(result.section, searchInTags).length !== 0)
		});
		const titleResults = miniSearchTitle.search(titleSearchField.value, {
			filter: (result, term, score, terms) => (selectedTags.length === 0 || getIntersection(result.combined_meta_data, selectedTags).length !== 0) &&
								(searchInTags.length === 0 || getIntersection(result.section, searchInTags).length !== 0)
		});
		contentResults.forEach((result) => {
			console.log(result.id)
		})
		titleResults.forEach((result) => {
			console.log(result.id)
		})

	});
});

function getIntersection(arr1, arr2) {
  if (arr1 === undefined || arr2 === undefined) {
	return []
  }
  return arr1.filter(value => arr2.includes(value));
}

function getSelectedTags() {
	var selectedTags = [];
  
	for (var option of rtaSelection.options) {
		if (option.selected) {
			selectedTags.push(option.value);
		}
	}
	for (var option of resSelection.options) {
		if (option.selected) {
			selectedTags.push(option.value);
		}
	}
	for (var option of facilitiesSelection.options) {
		if (option.selected) {
			selectedTags.push(option.value);
		}
	}
	return selectedTags
};

function getSearchInTags() {
	var selectedTags = [];
	
	for (var option of chkSelection.options) {
		if (option.selected) {
			selectedTags.push(option.value);
		}
	}
	return selectedTags
}

function indexPage(pageUrl) {
	fetch(pageUrl)
		.then(response => response.text())
		.then(htmlContent => {
			var doc = new DOMParser().parseFromString(htmlContent, 'text/html');
			const title = doc.querySelector('title').textContent.trim();
			const content = doc.querySelector('body').textContent.trim();
			const metaTags = doc.querySelector('head').getElementsByTagName('meta')
			const metaInfo = {};
			var tagList = [];

			for (let tag of metaTags) {
				if (tag.getAttribute('name')) {
					tagList = [];
					if (tag.getAttribute('name') in metaInfo) {
						tagList = metaInfo[tag.getAttribute('name')]
					}
					tagList.push(tag.getAttribute('content'));
					metaInfo[tag.getAttribute('name')] = tagList;
				}
			}

			miniSearchContent.add({
				id: pageUrl,
				content: content,
				combined_meta_data: metaInfo.combined_meta_data,
				section: metaInfo.section
			});
			miniSearchTitle.add({
				id: pageUrl,
				title: title,
				combined_meta_data: metaInfo.combined_meta_data,
				section: metaInfo.section
			});
		})
		.catch(error => {
			console.error('Failed to index page: ' + pageUrl)
			console.error(error);
		});
}