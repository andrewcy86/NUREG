import os
import re
import json
from bs4 import BeautifulSoup
import pathlib

base_folder = os.getcwd()
input_path  = pathlib.PureWindowsPath(base_folder + "\\nureg-doc\\output\\").as_posix() + "/"
output_path = pathlib.PureWindowsPath(base_folder + "\\nureg-doc\\file_groups.json").as_posix()


# Function to parse the filenames and create the structured dictionary
def process_files(directory):
    file_structure = {}
    file_pattern = re.compile(r'(\d+)_(\d+)_.*')

    # Read files from the directory
    files = [f for f in os.listdir(directory) if os.path.isfile(os.path.join(directory, f))]

    for file in files:
        title = ""
        with open(input_path + file, 'r', encoding='utf-8', errors='ignore') as html_file:
            soup = BeautifulSoup(html_file, 'html.parser')
            if soup.head == None:
                print(file + " has no title")
            else:
                title = soup.head.title.contents[0].strip()

        match = file_pattern.match(file)
        if match:
            header_num = int(match.group(1))
            section = int(match.group(2))

            if section not in file_structure:
                file_structure[section] = {"section": None, "children": []}

            if file_structure[section]["section"] is None or header_num < file_structure[section]["section"]["header_num"]:
                if file_structure[section]["section"]:
                    file_structure[section]["children"].append(file_structure[section]["section"])
                file_structure[section]["section"] = {"header_num": header_num, "title": title,"filename": file}
            else:
                file_structure[section]["children"].append({"header_num": header_num, "title": title, "filename": file})

    # Sort children by header_num within each group
    for group in file_structure.values():
        group["children"] = sorted(group["children"], key=lambda x: x["header_num"])

    return file_structure

# Function to write the structure to a JSON file
def write_to_json(file_structure, output_file):
    with open(output_file, 'w') as json_file:
        json.dump(file_structure, json_file, indent=4)

# Main function
def main():
    file_structure = process_files(input_path)
    write_to_json(file_structure, output_path)

    print(f'Structure written to {output_path}')

if __name__ == "__main__":
    main()