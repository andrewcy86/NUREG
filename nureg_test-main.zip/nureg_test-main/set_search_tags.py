import json
import openpyxl
import os
import re
from bs4 import BeautifulSoup
import pathlib

base_folder = os.getcwd()

file_path = pathlib.PureWindowsPath(base_folder + "\\nureg-doc\\MetaTagDict.xlsx").as_posix()
folder_path = pathlib.PureWindowsPath(base_folder + "\\nureg-doc\\output\\").as_posix() + "/"
output_path = pathlib.PureWindowsPath(base_folder + "\\nureg-doc\\file_titles.json").as_posix()



# file_path = 'E:/nrc_python/nureg_test2/nureg-doc/MetaTagDict.xlsx'
# folder_path = "E:/nrc_python/nureg_test2/backup/"
# output_path = "E:/nrc_python/nureg_test2/nureg-doc/file_titles.json"
file_dict = set()
headers = ["Section", "#", "Issue Title", "Lead Branch", "Resolution Product Category", "Date of Resolution", "Facility Type", "Related Technical Area", "Combined Meta Data"]
doc_title_dict = {}

def add_html_meta_tags(html_file, row):
    with open(folder_path + html_file, 'r+', encoding='utf-8', errors='ignore') as file:
        soup = BeautifulSoup(file, 'html.parser')

        doc_title_dict[html_file] = row[2]

        # Find the <head> tag and append the new <meta> tags to it
        head = soup.head
        if head:
            for i in range(0, 9):
                if(i == 1 or i == 2 or i ==3):
                    continue
                if(row[i] != "NULL"):
                    for tag in str(row[i]).split(','):
                        meta_tag = soup.new_tag('meta', content=tag.replace(".", ""))
                        meta_tag['name'] = headers[i].replace(" ", "_").lower()
                        head.append(meta_tag)

        file.seek(0)
        file.write(str(soup))
        file.truncate()

def load_excel_to_array(file_path):
    # Load the workbook and the active sheet
    workbook = openpyxl.load_workbook(file_path)
    sheet = workbook.active

    # Initialize the array to store the sheet data
    data_array = []

    # Iterate through each row and column in the sheet
    for row in sheet.iter_rows(values_only=True):
        data_array.append(list(row))

    return data_array

def write_to_json(file_structure, output_file):
    with open(output_file, 'w') as json_file:
        json.dump(file_structure, json_file, indent=4)

# Load the Excel file into a 2D array
data_array = load_excel_to_array(file_path)

for filename in os.listdir(folder_path):
    if filename.endswith('.html'):
        file_dict.add(filename)

# Print the resulting array (for testing purposes)
for filename in os.listdir(folder_path):
    if filename.endswith('.html'):
        for row in data_array:
            tag = str(row[1]).replace(".", "\\.").replace(" ", "_").lower()
            if re.search(tag, filename.lower()):
                if filename in file_dict:
                    file_dict.remove(filename)
                    add_html_meta_tags(filename, row)

write_to_json(doc_title_dict, output_path)