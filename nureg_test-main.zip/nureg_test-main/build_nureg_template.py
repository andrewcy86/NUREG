import os
import shutil
import uuid
from bs4 import BeautifulSoup
import copy
import json
import re
import pathlib

base_folder = os.getcwd()
folder_path = pathlib.PureWindowsPath(base_folder + "\\nureg-doc\\output\\").as_posix() + "/"
template_file = pathlib.PureWindowsPath(base_folder + "\\nureg-doc\\nureg_template\\nureg_template.html").as_posix()
json_file = pathlib.PureWindowsPath(base_folder + "\\nureg-doc\\file_groups.json").as_posix()
file_title = pathlib.PureWindowsPath(base_folder + "\\nureg-doc\\file_titles.json").as_posix()

# Change Directory Path
# folder_path = "E:/nrc_python/nureg_test2/" 
# template_file = "E:/nrc_python/nureg_test2/nureg_template/nureg_template.html"
# json_file = "E:/nrc_python/nureg_test2/nureg-doc/file_groups.json"
# file_title = "E:/nrc_python/nureg_test2/nureg-doc/file_titles.json"

def insert_toc_nureg_template(html_file, soup_toc, enable_toggle=True):
    with open(html_file, 'r+', encoding='utf-8', errors='ignore') as file:
        soup = BeautifulSoup(file, 'html.parser')
        
        # Remove the header tag from orignal html file. New header within NuReg tempalte will be added
        h2_header = soup.find('h2')
        if h2_header:
            h2_header.decompose()
        
        h1_header = soup.find('h1')
        if h1_header:
            h1_header.decompose()
            
        body_element = soup.find('body')
        
        nureg_template = open(template_file, 'r', encoding='utf-8', errors='ignore')
        nureg_soup = BeautifulSoup(nureg_template, 'html.parser')
        src, file_ext = os.path.splitext(os.path.basename(html_file))
        
        name_pattern = r"(\d+)_(\d+)_"
        
        body = soup.body
        if body:
            # Rebuild with top level div, toc div and main content div within the nureg template            
            temp_h1 = nureg_soup.find('h1')
            if enable_toggle == False:
                temp_h1.decompose()
            else:
                clean_src = re.sub(name_pattern, "", src)
                temp_h1.string = (clean_src.replace("_", " ")).title()
            
            top_div = soup.new_tag('div')
            content_div = soup.new_tag('div')
            content_div.attrs['id'] = "main_cont_id"
            content_div.attrs['class'] = "main-cont"
            
            if enable_toggle == True:
                content_div.append(copy.copy(temp_h1))
            content_div.append(copy.copy(body_element))
            
            btn_nav = soup.new_tag('button')
            btn_nav.attrs["class"] = "open_toc"
            btn_nav.string = "☰ Toggle Table of Contents"
            
            if enable_toggle:
                top_div.append(btn_nav)
                top_div.append(soup.new_tag('p'))
            
            top_div.append(copy.copy(soup_toc))
            p_vspacer = soup.new_tag('p')
            p_vspacer.attrs["class"] = "p_vspacer"
            top_div.append(p_vspacer)
            top_div.append(content_div)
            
            if enable_toggle:
                btn_script = soup.new_tag('script')
                btn_script.string = """var acc = document.getElementsByClassName("open_toc");
    if (acc)
    {
      acc[0].addEventListener("click", function() {
        this.classList.toggle("active")
        var panel = document.getElementById("toc");
        if (panel.style.display == "grid") {
          panel.style.display = "none";
        }
        else {
          panel.style.display = "grid";
        }
  
      });
    }"""
                top_div.append(btn_script)
            
            nested_body = top_div.find('body')
            nested_body.name = "div"   # remove the extra body tag. This is to remove the body tag from the base html file, 
                                       # as the we are going to use the body tag from nureg template
            
            
            temp_h1.decompose()

            temp_body = nureg_soup.find('p', recursive=True, string='[Body Content]')
            temp_body.string = ""
            temp_body.insert(1,copy.copy(top_div))

        
        nureg_title = nureg_soup.title
        if nureg_title:
            nureg_title.string = (src.replace("_", " ")).title()
        
        nureg_head = nureg_soup.head
        if nureg_head:
            toggle_style = nureg_soup.new_tag('style')
            toggle_style.string = """
            .open_toc {
      background-color: #eee;
      color: #444;
      cursor: pointer;
      padding: 18px;
      width: 100%;
      border: none;
      text-align: left;
      outline: none;
      font-size: 15px;
      transition: 0.4s;
      border-radius: 10px;
    }
    
    .active, .open_toc:hover {
      background-color: #ccc; 
    }
    

    .toc_grid {
      display:none;
      grid-template-columns: 250px 1fr;
      gap: 30px;
      border-radius: 10px;
      background-color: white;
      height: 35vh;
      overflow-y: scroll;
      padding:20px
    }
    
    .toc_grid_index {
      display:grid;
      grid-template-columns: 250px 1fr;
      gap: 30px;
      border-radius: 10px;
      background-color: white;
    }

    
    .gird_panel_search {
      padding:10px;
      background-color: rgb(219, 219, 219);
      border-radius: 10px;
    }

    .gird_panel_toc {
      padding:10px;
      background-color: rgb(219, 219, 219);
      border-radius: 10px;
    
    .p_vspacer {
        display:block;
        height:50px;
    }
            """
            nureg_head.append(toggle_style)
            
            
        minisearch_tag = soup.new_tag('script', src='https://cdn.jsdelivr.net/npm/minisearch@6.3.0/dist/umd/index.min.js')
        searchscript_tag = soup.new_tag('script', src='scripts/index.js')
    
        nureg_head.append(minisearch_tag)    
        nureg_body = nureg_soup.body
        if nureg_body:
            nureg_body.append(searchscript_tag)

        
        file.seek(0)
        file.write(nureg_soup.prettify())
        file.truncate()
        nureg_template.close()
        
def create_div_embeded_tag(soup, tag, tag_string=None, tag_id=None, tag_class=None, tag_input_type=None, dd_select_type=None, 
                           tag_name=None, tag_value=None, tag_title=None, tag_inline_style = None, tag_placeholder=None, div_id=None, div_class=None, inline_style=None, div_string=None):
    em_div = soup.new_tag("div")
    if div_id is not None:
        em_div.attrs["id"] = div_id
    if div_class is not None:
        em_div.attrs["class"] = div_class
    if inline_style is not None:
        em_div.attrs["style"] = div_class
    if div_string is not None:
        em_div.string = div_string
    
    new_tag = soup.new_tag(tag)
    if tag_id is not None:
        new_tag.attrs["id"] = tag_id
    if tag_string is not None:
        new_tag.attrs["string"] = tag_string
    if tag_class is not None:
        new_tag.attrs["class"] = tag_class
    if tag_input_type is not None:
        new_tag.attrs["type"] = tag_input_type
    if dd_select_type is not None and tag == "select":
        new_tag.attrs["multiple"] = dd_select_type
    if tag_name is not None:
        new_tag.attrs["name"] = tag_name
    if tag_value is not None:
        new_tag.attrs["value"] = tag_value
    if tag_title is not None:
        new_tag.attrs["title"] = tag_title
    if tag_inline_style is not None:
        new_tag.attrs["style"] = tag_inline_style
    if tag_placeholder is not None:
        new_tag.attrs["placeholder"] = tag_placeholder
    if tag == "select":
        new_tag.attrs["size"] = "1"
        
    em_div.append(new_tag)
    
    return em_div
    

def create_toc(soup, toggle=True):
    
    if toggle == False:
        h_tag = soup.new_tag('h1')
        h_tag.string = ' ☰ Table of Contents:'
        soup.append(h_tag)
    
    
    file_pattern = re.compile(r'(\d+)_(\d+)_(abstract|abbreviations|introduction).html')
    
    f_title = []
    
    with open(file_title) as t:
        f_title = json.load(t)
    
    
    with open(json_file) as f:
        jobj = json.load(f)
        key_list = []
        for k ,v in jobj.items():
            key_list.append(v)
        
        # Insert search element.
        
        toc_grid = soup.new_tag('div', id="toc")
        if toggle:
            toc_grid.attrs["class"] = "toc_grid"
        else:
            toc_grid.attrs["class"] = "toc_grid_index"
            
        search_div = soup.new_tag('div', id="search_div")
        search_div.attrs["class"] = "grid_panel_search"
        
        search_issue_input = create_div_embeded_tag(soup, tag="input", tag_id="content_search", tag_name="content", tag_title="Use double quotes to search by whole words", tag_placeholder="Issue contains")
        search_title_input = create_div_embeded_tag(soup, tag="input", tag_id="title_search", tag_name="title", tag_title="Use double quotes to search by whole words", tag_placeholder="Title contains")
        search_related_input = create_div_embeded_tag(soup, tag="input", tag_id="related_search", tag_name="relatedEvents", tag_title="Use double quotes to search by whole words", tag_placeholder="Related License Events contains")
        rta_dd = create_div_embeded_tag(soup, tag="select", tag_id = "rta-multi-select", tag_name="rta",dd_select_type="multiple", div_string="Related Technical Area")
        res_dd = create_div_embeded_tag(soup, tag="select", tag_id = "res-multi-select", tag_name="res",dd_select_type="multiple", div_string="Resolution Product Category")
        facility_dd = create_div_embeded_tag(soup, tag="select", tag_id = "facilities-multi-select", tag_name="facilities",dd_select_type="multiple", div_string="Facilities Type")
        chk_dd = create_div_embeded_tag(soup, tag="select", tag_id = "chk-multi-select", tag_name="chk",dd_select_type="multiple", div_string="Search in")
        
        reset_button = create_div_embeded_tag(soup, tag="input",tag_id="reset", tag_input_type="reset", tag_value="Reset")
        submit_button = create_div_embeded_tag(soup, tag="input",tag_id="submit", tag_input_type="submit", tag_value="Submit")
        
        search_div.append(search_issue_input)
        search_div.append(search_title_input)
        search_div.append(search_related_input)
        search_div.append((soup.new_tag("p")))
        search_div.append(rta_dd)
        search_div.append(res_dd)
        search_div.append(facility_dd)
        search_div.append(chk_dd)
        search_div.append(reset_button)
        search_div.append(submit_button)
        # search_bar = soup.new_tag('input', type="text", id="content_search")
        # search_group_form = soup.new_tag('form')
        # search_group_form.append(soup.new_tag('input', list="Group", id="GroupSelection"))
        # search_group_datalist = soup.new_tag('datalist', id="Group")
        # search_group_datalist.append(soup.new_tag('option', value="A"))
        # search_group_datalist.append(soup.new_tag('option', value="B"))
        # search_group_button = soup.new_tag('button', id="Button", type="button")
        # search_group_button.append("Search")
        # search_group_form.append(search_group_datalist)
        # search_group_form.append(search_group_button)

        # search_div.append(search_bar)
        # search_div.append(search_group_form)
        # search_div.append(soup.new_tag('textarea', id='SearchOutput'))
        toc_grid.append(search_div)        
        
        grid_panel = soup.new_tag('div', id="toc_list")
        grid_panel.attrs["class"] = "grid_panel_toc"
        
        name_pattern = r"(\d+)_(\d+)_"
        for item in key_list:            
            match_hdr = file_pattern.match(item["section"]["filename"])
            if match_hdr:
                it = soup.new_tag('div')
                plink = soup.new_tag('a', href=item["section"]["filename"])
                # plink.string = re.sub(name_pattern, "", (item["section"]["title"]).title())
                plink.string = f_title[item["section"]["filename"]]
                it.append(plink)
                grid_panel.append(it)
                soup.append(grid_panel)
            else:    
                det = soup.new_tag('details')
                sum = soup.new_tag('summary')
                # sum.string = re.sub(name_pattern,"",(item["section"]["title"]).title())
                sum.string = f_title[item["section"]["filename"]]
                det.append(sum)
                ul = soup.new_tag('ul')
                li = soup.new_tag('li')
                new_link = soup.new_tag('a', href=item["section"]["filename"])
                new_link.string = "Description"
                li.append(new_link)
                ul.append(li)
                if len(item["children"]) > 0:
                    for child in item["children"][1:]:
                        li_child = soup.new_tag('li')
                        child_link = soup.new_tag('a', href=child["filename"])
                        # child_link.string = re.sub(name_pattern, "", (child["title"]).title())
                        child_link.string = f_title[child["filename"]]
                        li_child.append(child_link)
                        ul.append(li_child)
                    
                
                det.append(ul)
                grid_panel.append(det)
                toc_grid.append(grid_panel)
                soup.append(toc_grid)
    
def build_index():
    soup = BeautifulSoup(features="html.parser")
    
    html_tag = soup.new_tag('html')
    head_tag = soup.new_tag('head')
    title_tag = soup.new_tag('title')
    title_tag.string = 'Table of Contents'
    head_tag.append(title_tag)
    html_tag.append(head_tag)
    body_tag = soup.new_tag('body')
    html_tag.append(body_tag)
    soup.append(html_tag)
    
    with open(folder_path + "index.html", 'w', encoding='utf-8') as file:
        file.write(soup.prettify())

def process_html_files(folder_path):
    html_files = []
    build_index()
    for filename in os.listdir(folder_path):
        if filename.endswith('.html'):
            html_file = os.path.join(folder_path, filename)
            html_files.append(html_file)
            
    soup_toc = BeautifulSoup(features="html.parser")
    create_toc(soup_toc)
    
    soup_toc_index = BeautifulSoup(features="html.parser")
    create_toc(soup_toc_index,False)
    
    for filename in html_files:
        print("Apply nureg template to file: ", filename)

        if filename.endswith('index.html'):
            insert_toc_nureg_template(filename, copy.copy(soup_toc_index),False)
        else:
            insert_toc_nureg_template(filename, copy.copy(soup_toc))
            
        # if filename.endswith('index.html'):
        #     insert_toc_nureg_template(filename, copy.copy(soup_toc_index), False)
        # # #     # insert_toc_nureg_template(filename, copy.copy(soup_toc))
            


process_html_files(folder_path)