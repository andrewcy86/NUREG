import csv
import os
import shutil
import uuid
from bs4 import BeautifulSoup
import pathlib

# Change Directory Path
base_folder = os.getcwd()
folder_path = pathlib.PureWindowsPath(base_folder + "\\nureg-doc\\output\\").as_posix() + "/"

REMOVE_IMAGE_WIDTH = 275
REMOVE_IMAGE_HEIGHT = 15

file_dict = {}

def extract_image_sources(html_file, image_sources):
    with open(html_file, 'r+', encoding='utf-8', errors='ignore') as file:
        soup = BeautifulSoup(file, 'html.parser')
        
        src, _ = os.path.splitext(os.path.basename(html_file))

        title = soup.new_tag('title')
        title.string = src

        # Find the <head> tag and append the new <title> tag to it
        head = soup.head
        if head:
            head.append(title)

        # Find all img tags
        imgs = soup.find_all('img')
        
        # Extract src attribute from each img tag
        for img in imgs:
            src, ext = os.path.splitext(img.get('src'))
            if src:
                new_file_link = "images/" + str(uuid.uuid1()) + ext
                new_file = folder_path + new_file_link
                #new_file = folder_path + "images/" + str(uuid.uuid1()) + ext
                shutil.copy(folder_path + src + ext, new_file)
                img['src'] = new_file_link
                image_sources.append(folder_path + src + ext)
                if(int(img.get('width')) > REMOVE_IMAGE_WIDTH and int(img.get('height')) < REMOVE_IMAGE_HEIGHT):
                    try:
                        shutil.copy(new_file, folder_path + "bad_images/" + new_file_link)
                        os.remove(new_file)
                        img.decompose()
                    except Exception as e:
                        print(e)

        file.seek(0)
        file.write(soup.prettify())
        file.truncate()

def clean_up(image_sources):
    for src in image_sources:
        if(os.path.dirname(src).endswith('_files')):
            try:
                shutil.rmtree(os.path.dirname(src))
            except Exception as e:
                print(e)

# def build_index(html_files):
#     soup = BeautifulSoup(features="html.parser")
    
#     minisearch_tag = soup.new_tag('script', src='https://cdn.jsdelivr.net/npm/minisearch@6.3.0/dist/umd/index.min.js')
#     searchscript_tag = soup.new_tag('script', src='scripts/index.js')
#     html_tag = soup.new_tag('html')
#     head_tag = soup.new_tag('head')
#     title_tag = soup.new_tag('title')
#     title_tag.string = 'Table of Contents'
#     head_tag.append(minisearch_tag)
#     head_tag.append(title_tag)
#     html_tag.append(head_tag)
    
#     body_tag = soup.new_tag('body')
#     h1_tag = soup.new_tag('h1')
#     h1_tag.string = 'Table of Contents: '
#     ol_tag = soup.new_tag('ol')

#     #Build table of contents
#     for html_file in html_files:
#         src, ext = os.path.splitext(os.path.basename(html_file))
#         li_tag = soup.new_tag('li')
#         #a_tag = soup.new_tag('a', href=html_file)
#         a_tag = soup.new_tag('a', href=src+ext)
#         a_tag.string = src
#         li_tag.append(a_tag)
#         ol_tag.append(li_tag)
    
#     #Build search section
#     search_div = soup.new_tag('div')
#     search_bar = soup.new_tag('input', type="text", id="Query")
#     search_group_form = soup.new_tag('form')
#     search_group_form.append(soup.new_tag('input', list="Group", id="GroupSelection"))
#     search_group_datalist = soup.new_tag('datalist', id="Group")
#     search_group_datalist.append(soup.new_tag('option', value="A"))
#     search_group_datalist.append(soup.new_tag('option', value="B"))
#     search_group_button = soup.new_tag('button', id="Button", type="button")
#     search_group_button.append("Search")
#     search_group_form.append(search_group_datalist)
#     search_group_form.append(search_group_button)

#     search_div.append(search_bar)
#     search_div.append(search_group_form)
#     search_div.append(soup.new_tag('textarea', id='SearchOutput'))

#     body_tag.append(h1_tag)
#     body_tag.append(ol_tag)
#     html_tag.append(body_tag)
#     html_tag.append(search_div)
#     html_tag.append(searchscript_tag)
    
#     soup.append(html_tag)
    
#     with open(folder_path + "index.html", 'w', encoding='utf-8') as file:
#         file.write(soup.prettify())

def process_html_files(folder_path):
    html_files = []
    image_sources = []
    if(os.path.exists(folder_path + "images/")):
        shutil.rmtree(folder_path + "images/")
    os.mkdir(folder_path + "images/")
    
    for filename in os.listdir(folder_path):
        if filename.endswith('.html'):
            html_file = os.path.join(folder_path, filename)
            print("processing: ", html_file)
            extract_image_sources(html_file, image_sources)
            print(html_file)
            html_files.append(html_file)
            
    print("Image Sources Found:")
    for src in image_sources:
        print(src)
    # build_index(html_files)
    clean_up(image_sources)

process_html_files(folder_path)